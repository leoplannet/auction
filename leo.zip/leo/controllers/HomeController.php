<?php



	class HomeController
	{
		
		//Просмотр всех статей на Главной + пагинация
		public function actionHome()
		{
			
			// Вывод всех статей на главной
			$home_pop = array();
			$home_pop = home::getHomePopular();
						
			
						
			require_once(ROOT . '/views/home/index.php');
			
			return true;
		}
		

	}
	

?>