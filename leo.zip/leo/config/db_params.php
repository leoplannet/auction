<?php

/*return array(
			'host' => 'localhost',
			'dbname' => 'leoplannet-auction',
			'user' => 'admin',
			'password' => 'qwerty123456',
);*/return array(
			'host' => 'localhost',
			'dbname' => 'leo_planet',
			'user' => 'root',
			'password' => '',
);