<?php

	return array(

		//Регистрация
		'login' => 'user/login',
		'registr' => 'user/register',
		
		//Главная
		'' => 'home/home',
		
		
		

	);

?>