<?php

//Класс User - модель для работы с пользователями

class Category
{

	// Проверяем является ли пользователь гостем
    public static function GetCategory()
    {
		$db = Db::getConnection();	
		$sql = 'SELECT * FROM Category';
		$result = $db->query($sql);
        $resultlist = array(); 
		$i=0;

		while ($row = $result->fetch()) {
			$resultlist[$i]['id']=$row['Categoty_id'];
			$resultlist[$i]['Name']=$row['Name'];
			$i++;

		} ?>
		
		<?php  foreach ($resultlist as $home_array):  ?>
        
            <div class="katalog_bottom_item">
               <img src="/template/img/katalog_item.png">
                 <p>

                 <?php   echo $home_array['Name'];   ?></p>
            </div>
          
        
          <?php endforeach; ?>
          
<?php 
    }


	

}
 ?>
