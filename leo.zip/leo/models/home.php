<?php

	class Home
	{
		
		// Количество отображаемых лотов по умолчанию
		const SHOW_BY_DEFAULT = 8;

		
		//Вывод популярніх лотов на главной странице
		public static function getHomePopular()
		{
			$limit = home::SHOW_BY_DEFAULT;
			
			//Подключение к БД
			$db = Db::getConnection();
			
				$home_popular_array = array();
                
				// Текст запроса к БД
				$sql = 'SELECT * FROM lots '
                . 'ORDER BY id DESC';
				
				
				// Используется подготовленный запрос
				$result = $db->prepare($sql);
				
				// Выполнение коменды
				$result->execute();
				
				//формирование массива
                if ($result) {
 				 $i = 0;
  				 while($row = $result->fetch()) {
					$home_popular_array[$i] = $row;
					$i++;
				 }
				 
				}
				return $home_popular_array;	
				
		}
		
		
		
		//Возвращает путь к изображению
		public static function getImage($id)
		{
			// Название изображения-пустышки
			$noImage = 'no-image.jpg';

			// Путь к папке с лотами
			$path = '/template/img/';

			// Путь к изображению лота
			$pathToImage = $path . $id . '.jpg';

			if (file_exists($_SERVER['DOCUMENT_ROOT'].$pathToImage)) {
				// Если изображение для товара существует
				// Возвращаем путь изображения товара
				return $pathToImage;
			}

			// Возвращаем путь изображения-пустышки
			return $path . $noImage;
		}
		
	}

?>