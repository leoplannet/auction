$(document).ready(function(){
      $('.bxSlider').bxSlider({
     auto: true,
     pause: 2600

  });
      $('.bx-wrapper').css("border","none").css("margin-bottom","0px");
      $('.bx-wrapper li').css("width","1300px");
      $('.bx-wrapper .bx-pager').css("bottom","22px");
      /*$('.bx-wrapper .bx-pager.bx-default-pager a').css("background","#212121").css("width","13px").css("height","13px").css('background',"#212121");*/


    });