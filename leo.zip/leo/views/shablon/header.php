<!DOCTYPE html>
<html>
<head>
<title>AUCTION LeoPlannet</title>
<?php include_once ROOT . '/models/category.php' ?>


<link href="/template/css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
<link href="/template/css/bootstrap-theme.css" rel="stylesheet" type="text/css" media="screen">
<link href="/template/css/fonts.css" rel="stylesheet">
<link href="/template/fonts/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/template/js/jquery.bxslider.js"></script>
        <link rel="stylesheet" type="text/css" href="/template/css/jquery.bxslider.css">
<script type="text/javascript" src="/template/js/common.js"></script>
<link href="/template/css/style.css" rel="stylesheet" type="text/css" media="screen" />


 <!-- зальєш в цей файл всі потрібні стилі і вичишеш файл так щоб лишніх не було стилів -->


</head>
	<body>		
		 <header class="header">
 <div class="container clearfix">
    <div class="header_top clearfix">
     <div class="header_top_left clearfix"><a href=""><img src="/template/img/logo.png"></a></div>
     <div class="header_top_center clearfix">
         <form class="header_top_center_form">
         <input type="text" name="Name" class="hammel" placeholder="Искать Аукцион">
         <input type="text" name="Locate" class="locate" placeholder="Вся Украина">
         <input type="submit" name="Send" value="" class="send">
         </form>
     </div>
     <div class="header_top_right clearfix">
         <div class="header_top_right_not_autorisation clearfix">
         <a href="">Регистрация</a>
             <a href="">Вход</a>
           
         </div>
     </div>
     <div class="header_top_bottom">
       <div class="header_top_bottom_left">
           <nav>
               <ul class="navigation">
                   <li class="home_linck"><a href=""><img src="/template/img/home.png"></a></li>
                   <li><a href="">Торги</a></li>
                   <li><a href="">Контакти</a></li>
                   <li><a href="">Новости</a></li>
                   <li><a href="">Регламент</a></li>
                   <li><a href="">Безопасная зделка</a></li>
                   <li><a href="">Вопроси и ответи</a></li>
               </ul>
           </nav>
       </div>  
     </div>
    </div>

 </div>
</header>

        <div class="container clearfix">
        <div class="katalog_bottom clearfix">
        <?php 
        
        Category::GetCategory(); ?>
		 </div>
     </div>
