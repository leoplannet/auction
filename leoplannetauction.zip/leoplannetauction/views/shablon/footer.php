
<footer class="footer">
    <div class="container clearfix">
        <div class="footer_center clearfix">
            <div class="footer_center_left">
                <nav class="footer_center_left_nav">
                    <li><a href="">Торги</a></li>
                    <li><a href="">Контакти</a></li>
                    <li><a href="">Новости</a></li>
                    <li><a href="">Регламент</a></li>
                    <li><a href="">Безопасная зделка</a></li>
                    <li><a href="">Вопроси и ответи</a></li>
                </nav>
            </div>
            <div class="footer_center_right clearfix">
            <h2 class="footer_center_right_top">
                Другие нашие  проекти
            </h2>
            <div class="footer_center_right_line"></div>
            <div class="footer_center_right_items">
                <div href="" class="footer_center_right_items_link">
                    <img src="/template/img/first_project.jpg">
                    <a href="">leoplannet.com.ua</a>
                </div>
                <div href="" class="footer_center_right_items_link">
                    <img src="/template/img/first_project.jpg">
                    <a href="">leoplannet.com.ua</a>
                </div>
                <div href="" class="footer_center_right_items_link">
                    <img src="/template/img/three_project.jpg">
                    <a href="">leoplannet.com.ua</a>
                </div>
            </div>
        </div>
        
        </div>
        <div class="footer_bottom_center">
            <h3 class="footer_bottom_center_zag">Подпишитесь на наши новости</h3>
            <p class="footer_bottom_center_p">И ви первим узнаете о всех наших акциях спецпредложений  кидках</p>
            <form class="footer_bottom_form">
                <input id="s_email" type="email" value name="email" placeholder="Введите ваш e-mail адрес"><input type="submit" value="Подписка">
            </form>
            <div class="footer_bottom_bottom">
                <div id="">                                                                 
                             <ul class="footer-blogleoplannet-social">
                                 <li class="footer-blogleoplannet-social-li">
                                     <a href=""><i class="fa fa-facebook blogleoplannet-glyphicon-cloud" aria-hidden="true"></i></a>
                                 </li>
                                 <li class="footer-blogleoplannet-social-li">
                                    <a href=""> <i class="fa fa-twitter blogleoplannet-glyphicon-cloud"" aria-hidden="true"></i></a>
                                 </li>  
                                 <li class="footer-blogleoplannet-social-li">
                                     <a href=""><i class="fa fa-rss blogleoplannet-glyphicon-cloud"" aria-hidden="true"></i></a>
                                 </li>  
                                 <li class="footer-blogleoplannet-social-li">
                                     <a href=""><i class="fa fa-vk blogleoplannet-glyphicon-cloud"" aria-hidden="true"></i></a>
                                 </li>                              
                             </ul>
                </div>
                <p>Copyright 2016 <span class="yellow"><a href="">ArtLeoPlannet</a></span> All Rights Reserved.</p>
                <p id="timer">12.02.2017 <span>1</span><span>5</span><span>:</span><span>5</span><span>5</span></p>
            </div>
        </div>
        
    </div>		
			

	 
	</body>
</html>

