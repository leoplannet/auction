
<?php include ROOT.'/views/shablon/header.php';?>

		 
		 <!-------------------------------------------------------->
		 


<section class="center">
<div class="container">
    <ul class="bxSlider">
        <li class="slider_one">
        2
        </li>
        <li class="slider_two">
            <div class="slider_two_left">
                <p>ПРОДРАВАЙ свою технику<br>
                   с ЛОТА<br>
                   получив больше вигоди
                </p>
            </div>
            <div class="slider_two_right">
                <img src="/template/img/laptop.png">
            </div>
        </li>
        <li class="slider_three">2</li>
    </ul>
    </div>
</section>
<section class="lots">
    <div class="container clearfix">
        <h2 class="lots_zag">Популярние лоти</h2>
        <div class="footer_center_right_line"></div>
		
        <ul class="lots_items clearfix">
			 <?php foreach ($home_pop as $home_popular_array): ?>
		     <li>
				<div class="lots_items_item item_left">
					<div class="lots_items_item_top">
						<div class="lots_items_item_top_logo clearfix">
							<img src="<?  echo Home::getImage($home_popular_array['img']); ?>">
							<div class="lots_items_item_top_logo_menu clearfix">
								<span class="icon icon-auction"></span>
								<p class="lots_items_item_top_logo_menu_count">1 ставка</p>
								<span class="icon icon-stat"></span>
							</div>
						</div> 
						<p class="lots_items_item_top_zag"><?php  echo $home_popular_array['title'];  ?></p>                   
					</div>
					<div class="lots_items_item_center">
						<div class="lots_items_item_center_top">
							<p>К окончанию аукциона осталось</p>
						</div>
						<div class="lots_items_item_center_center">
						   <div class="lots_items_item_center_center_top">
							   <p><span class="days">02</span>
							   <span class="black_line"></span>
							   <span class="hours">01</span>
								<span class="black_line"></span>
							   <span class="minutes">51</span>
								<span class="black_line"></span>
								<span class="seconds">39</span>
							   </p>
						   </div>
						   <div class="lots_items_item_center_center_bottom">
							   <p><span>дней</span>
							  
							   <span class="hours">час</span>
								
							   <span class="minutes">мин</span>

								<span class="seconds">сек</span>
							   </p>
						   </div>
						</div>
						<div class="lots_items_item_bottom">
							<p>Стартовая цена : <span>2000 грн</span></p>
						</div>
					</div>
				</div>
			 </li>
			 <?php endforeach; ?>
        </ul>
		<!------------------ цикл вывода популярных лотов -------------------->
    </div>
</section>
<section class="news">
    <div class="container clearfix">
        <h2 class="lots_zag">Новости</h2>
        <div class="footer_center_right_line"></div>
        <div class="news_items">
            <div class="news_item news_item_first">
                <img src="/template/img/news_item.png">
                <p class="news_item_top">Ми откриваемся. Успей создасть свой лот, Первие 100 человек получат безплатно +10</p>
                <div class="black_horizontal_line"></div>
                <p class="news_item_bottom">23 листопада 2017</p>
            </div>
            
        </div>
    </div>
</section>

		 
		 <!-------------------------------------------------------->
		 
<?php include ROOT.'/views/shablon/footer.php';?>