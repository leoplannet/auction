-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 04 2017 г., 01:16
-- Версия сервера: 5.6.37
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `leoplannet-auction`
--

-- --------------------------------------------------------

--
-- Структура таблицы `auction-user`
--

CREATE TABLE `auction-user` (
  `id` int(11) DEFAULT NULL,
  `nickname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `auction-user`
--

INSERT INTO `auction-user` (`id`, `nickname`, `email`, `password`, `role`) VALUES
(1, 'admin', 'leoplannet-auction.admin@gmail.com', 'qwerty123456', 'admin');

-- --------------------------------------------------------

--
-- Структура таблицы `lots`
--

CREATE TABLE `lots` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(225) NOT NULL,
  `category_id` int(11) NOT NULL,
  `undocategory_id` int(11) NOT NULL,
  `img` varchar(50) NOT NULL,
  `date_begin` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `id_type_of_lot` int(11) NOT NULL,
  `price_auction` float NOT NULL,
  `price_buy` float NOT NULL,
  `curency_id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `views` int(11) NOT NULL,
  `id_winner` int(11) NOT NULL,
  `id_status` int(11) NOT NULL,
  `image2` varchar(50) NOT NULL,
  `image3` varchar(50) NOT NULL,
  `image4` varchar(50) NOT NULL,
  `image5` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `lots`
--

INSERT INTO `lots` (`id`, `title`, `description`, `category_id`, `undocategory_id`, `img`, `date_begin`, `date_end`, `id_type_of_lot`, `price_auction`, `price_buy`, `curency_id`, `id_user`, `views`, `id_winner`, `id_status`, `image2`, `image3`, `image4`, `image5`) VALUES
(1, 'ЛЕГКОВИЙ АВТОМОБІЛЬ ВАЗ 210994-20', '', 0, 0, 'auction', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
